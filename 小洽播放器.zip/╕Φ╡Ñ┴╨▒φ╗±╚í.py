import json
import requests
import re
import execjs
import os
headers = {
'cookie': 'nts_mail_user=xiaoqiabk@163.com:-1:1; _ntes_nnid=7e5859aea3c41e2a0f9c2d0c20cb85ac,1675342979786; _ntes_nuid=7e5859aea3c41e2a0f9c2d0c20cb85ac; WEVNSM=1.0.0; WNMCID=vndrku.1675342980228.01.0; WM_TID=2%2FSY4VUFqRpBUAEUFBaVLEZdD8YPb%2FF6; NMTID=00Ogb1J4QnXYwdqjkc9sB8g10OMnHgAAAGGEnCV-g; __snaker__id=DM99Ntm6L2l3PVAS; YD00000558929251%3AWM_TID=U4EGXVqeG0hABRQBFUbUKQJ98M7zpc6S; ntes_kaola_ad=1; YD00000558929251%3AWM_NI=SsyaYyWGEP%2FTInd1bUI21EW1EjUohY7GQPOiHqgbiGIknqw0vZtKPlelI6bkuFmzSh9dKZ886f1mVS7ECa59T13SrKkhe5ocqucoL5Hl7%2BDtKhHMBuvp7goRzsDj7zydMTg%3D; YD00000558929251%3AWM_NIKE=9ca17ae2e6ffcda170e2e6eea6f63e82af999bc72593968eb6c84a969b9b83c14588a69e82c46faaafb690c92af0fea7c3b92a91adb782dc7395998bb1ae608bb2acd2e15f8beeffa6d63b87b69b90eb53f5999fb1ce638cafa983ec4d8bb5a292f63cb686bcacd368a7b487d7e161b79aa39bd264fbbc85bbbb34f6baff8ed559f59b8d82b83398effdb4f141a9b8abd6ee69b3abad90cf3f8cb4f9ccc78089b888aec17fb6b0f988ee5abaad8c8bb672bbbc83b5e637e2a3; NTES_P_UTID=jbf1dOigwHK1GnmQ4F0qVYmyVRS4B6SR|1680237350; NTES_PASSPORT=6qPXS82nha4zvGlanvE6dgjR2Fw9nJVhW_KSlOdRtI_ptMe.tG1VzrRVk6rKmRORI.5X6sBb9VE6eT3GHHUuhLu5M5WL2IOofI0CSsfd1T1HsIA4vTywrLK2mfXBiy1uvIa5uzXN3X9BIEb7.snqrkS2.v9e0Jqt3UUpMkTrThZKjg91vkuVJ5t.TD5iRAgM5; P_INFO=xiaoqiabk@163.com|1680237350|1|mail163|00&99|US&1678535936&mail163#heb&130600#10#0#0|&0|mail163|xiaoqiabk@163.com; WM_NI=aCcbnS%2BtqdAuQ1RAmuVSFh0sueGc%2FoekZpejJk%2F8yVbUcN8p2DvHG6g%2FomCrDzQrazuZNfGyqLfA9dXyHg9zCO6TSZxc17FK6b8%2FvixiVSw6A%2BISeSmTHcae%2BQHDmluJbzY%3D; WM_NIKE=9ca17ae2e6ffcda170e2e6eed4d373f3bd9888c963a9eb8aa2d45e969e8badd46aaf89a5abca6aaf94a7d9d02af0fea7c3b92aa39dad83ed59e9acbf85c47f93ef9ea2f07f968d8a89b379b7bb8984ae65a7b59691e8628ab5e1d9fc5ea28badafbb7cf29cbaa9c63ea5f1a18ec27a88a69f93e472b7868287c673b394aaa2bc709ca78888bc728191fab5d252bcbdffd8c541f6bef8d0f563bcb79ab4f63e83f587b4e859af8c8884e46fe98f88a5f068b796ae9bdc37e2a3; playerid=58319376; JSESSIONID-WYYY=bZmnPNur8F%2BzwNYYWF79EK1lcFkUzonJ6vn41rzyE8tRamRTR57Q%2FYEQzkA%2B34I1Gjngi0krbZh8J1NpZJOCDb5Z8MFO0%2BoT2uooImwl86%5Cg%2B4V8lPw%5CVKq%2FQCKa%2BZ2m5klAurnNMiuRj%2B9G8HRZe7AIRbBOK6tbQOPdsXRktvz%5C%2BsSP%3A1680616780609; _iuqxldmzr_=33',
'referer': 'https://music.163.com/discover/toplist?id=3778678',
'origin': 'https://music.163.com',
'user-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 SE 2.X MetaSr 1.0',
}# 伪装爬虫
data = {
'params':'TVBKl4sNlH+Ph7VmmCz4SU9fJxYkseiulNo7c9O5seNj06eJwSP7ejaowTmRs2ncD6U4kr7u3joJQbEE5pm0GblUGvHIBdzXyr2jWMPgNoI=',
'encSecKey':'3dcce59faa96fece67064e2dc5a1c291c6760ec4256f49759fa49d1c6b4e191cf31b8681d1315d0c923ff995b668620c280b83d47a89556450bb4e3fa897560b3235906fd29b9823bc118ae21498e5d8a16735fdff8971febc510ce55e3708142dfe8f38381f8a6b42160a696eb9059ea8f4f293c1ec87a3a046e52af829dfd1',
}
url = 'https://music.163.com/weapi/v6/playlist/detail?csrf_token='
response = requests.post(url=url, data=data,headers=headers)
# print(response.text)
date = (response.text)
list_json = json.loads(str(date))# 转化文件格式把json格式转化成python字符串格式
# print(list_json["playlist"]['tracks'][i]['id'])#根据筛选获取其中重要的内容
list_text = {'name': '', 'album': '', 'cover': '', 'singer': '', "audio_url": "", "lyric": ""}#创建列表
#以下是歌曲信息爬去程序可以自行更改
with open(f'./musics.json', 'w', encoding='UTF-8', ) as f:
          for i in range(0,200):
               list_text['name'] = (list_json['playlist']['tracks'][i]['name'])
               list_text['singer'] = (list_json['playlist']['tracks'][i]['ar'][0]['name'])
               list_text['album'] = (list_json['playlist']['tracks'][i]['al']['name'])
               list_text['cover'] = (list_json['playlist']['tracks'][i]['al']['picUrl'])
               jianye_list = (list_json['playlist']['tracks'][i]['id'])
               jianwen_list = (list_json['playlist']['tracks'][i]['name'])
               music_url =f'http://music.163.com/song/media/outer/url?id={jianye_list}.mp3'
               xiao_url = f"http://music.163.com/api/song/lyric?id={jianye_list}+&lv=1&tv=-1"
               responses = requests.post(url=xiao_url,headers=headers)
               dates = responses.text
               json_lrc = json.loads(str(dates))
               text_lrc = (json_lrc['lrc']['lyric'])
               ls = re.findall('\d{2}:\d{2}.\d{2}|[\u4e00-\u9fa5].{1,}', text_lrc)
               list_text["lyric"] = ls
               list_text["audio_url"] = music_url
               json.dump(list_text, f, ensure_ascii=False)
print("music.json文件读写成功！")

# headeres = {
# 'cookie': 'NMTID=00Op-NREUv0fUee3Eb3rr8-v1EYUR8AAAGHQmUjRg; __remember_me=true; _ntes_nnid=998a3a97bbc2690bedbd1c291afa9c83,1680787748662; _ntes_nuid=998a3a97bbc2690bedbd1c291afa9c83; ntes_kaola_ad=1; WEVNSM=1.0.0; WNMCID=ksjheq.1680787755804.01.0; WM_TID=mBS0%2BjOBiZ9AUBRERRbEPydstQPrqdS%2B; __snaker__id=tH9249zWHUxJWRNr; gdxidpyhxdE=vvT2YnA9ApXjo%5CToBxxLcaap%2FX7dJDER4y2898BXRcKncaQuhea%2Fwa2C7u7Q7P1ijm1%2FSi6UMn6gxRuhfpT5HLt4qv4uCpnNZgYDnk7iNOMA%2BrrOT05f%5CxS0aVoBC%5CMMWW7Rn%2F1pqvMDYru7g3DX20zOxTpU6eTC7VL4GI7%2FtG3PIkqp%3A1681645056543; YD00000558929251%3AWM_NI=RBrogTSilet3%2FU9JlhlxvE%2BrWaWyyMrcvEtiF4pztqOd9jgKNZfM6auwDbkhMrW5meKVStzom4kzmEbuVn%2BzTHjlWyfgqvNEXq68w4DSJSImX3RREpf1ufVnhGKXl2ecY0g%3D; YD00000558929251%3AWM_NIKE=9ca17ae2e6ffcda170e2e6eed9e680a3b29fadf15cf4ef8ba6d55a879f8f83d445ad899994e546e9bee1b9b52af0fea7c3b92a929ebe90e66091b7a486f739ed8bf7abef64b0a8baa6aa7a95bf999afc47b2bdbaa6f76386ecc09bf77b8dbcf78be6418e86aaaeb56bb7a98c83ea648fae99d6f06f898a9d95f965afeca59bf04fa2ab9a8faa729898a68dd673a6b9bf97cd4f9caffad9f640888d86b4cc679ced9eb3c87ca6efbb87d566ac9985b9ef3aa7bd97d1e637e2a3; YD00000558929251%3AWM_TID=XvXkBNXwAnpFARBUQUaFftTH5bJuaqGv; MUSIC_U=7fe343f10afee45c81df80dedce374cee3b2ef321c9f86a5c724fad0669f09982db2b9020595718802b958216c360232c69a8a6c9578572e2bac26b1065168763c55e7b0f6c45828d4dbf082a8813684; __csrf=168c42a6728dc043b6a7f80d6b2e1191; JSESSIONID-WYYY=AB3IuzOoaNtGFxK9EkSCF%5C%5COEDPEzw30%2FEUO7A%2BDu1buS6pU%2FE1qfnjGis7uTBZe8m34Ja8oXfxDQg2RxJTVCruUmlRHnWDgQdtm8mXkZkzP4afEXjcJWhmYdV7E%2FggODUk%2FwfZiSslRtp1HbAIAwofixjlia0YBlfIEa0sqTkzVhcqA%3A1681993121243; _iuqxldmzr_=33; WM_NI=tVa3r%2B76bDdk1iK5gwuXLsWYyOeq2NYUdxliFfUMygIfG7%2FzCDcxT02oO2E5B0sIb7J3d5WtwrBonKedJPf1a1KSnVkMnOtyiVri0CUSwyHCbeyBwjZVzuATvhhVDqNuMzg%3D; WM_NIKE=9ca17ae2e6ffcda170e2e6eeb4aa7c91ad9dd7d67c91b08ea7d84f878b9eacc448adbaf8adf473aba6b9a2f02af0fea7c3b92ab88aafd4f121f5eaaea5e761f3b785d6e67db7888494d653bb91ab92b1469b8bac99ef6386ba9baefc6d8bba89d8ae72819cad99d73cf2b181d3c83f82f0bdaae13d8aedacd6d680b5ae8e90ed41a7bc86b1e53ba3ef85b4ed5ea993a2b0f773ab8abe8ab349978db99acb49a2bbb7a3f6629a8ab696c460b6b8a8b7c77b8eab839be637e2a3; playerid=41073003',
# 'referer': 'https://music.163.com/?from=itab',
# 'origin': 'https://music.163.com',
# 'user-agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 Edg/109.0.1518.95',
# 'sec-ch-ua': '"Not_A Brand";v="99", "Microsoft Edge";v="109", "Chromium";v="109"',
# }
# js = open('damo.js', 'r', encoding='utf-8').read()
# ctx = execjs.compile(js)
# os.environ["EXECJS_RUNTIME"] = "Node"
# dataes = ctx.call('start', input('歌曲ip:'))
# for i in range(0,200):
#   song_id = list_json["playlist"]['tracks'][i]['id']
#   url = f"http://music.163.com/api/song/lyric?id={song_id}+&lv=1&tv=-1"
#
#   print(requestes.text)
# # print(requests.text)
#
#
# json_lrc = json.loads(str(date))
# text_lrc = (json_lrc['lrc']['lyric'])
# ls = re.findall('\d{2}:\d{2}.\d{2}|[\u4e00-\u9fa5].{1,}',text_lrc)

