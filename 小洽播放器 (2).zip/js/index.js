
var musiclist = [];//列表
var currentIndex = 0;//歌曲最开始的播放顺序
var _audio = $('audio')[0];

            //1.加载音乐列表信息
$.ajax({
    type: "GET",
    url: "./music.json",
    dataType: "json",
    success: function (data){
        musiclist = data;
        console.log(musiclist)
        render(musiclist[currentIndex]);
        renderMusicList(musiclist);
        },
});
$("#playBtn").on("click",function (){
    if ($("audio").get(0).paused){      //如果歌曲是关闭状态则播放音乐
        $(this).removeClass('fa-play').addClass('fa-pause');//切换控件
        $("audio").get(0).play();//播放音乐
        //获取音乐总时长并改变页面数据
        if(_audio.readyState > 0) {
            let minutes = parseInt(_audio.duration / 60, 10);
            let seconds = parseInt(_audio.duration % 60);
            if (seconds < 10) {
                seconds = "0" + seconds
                $(".time").text("0" + minutes + ":" + seconds);
            } else {
                $(".time").text("0" + minutes + ":" + seconds);//获取歌曲总时长
                }
        }
        $(".cover").css({
            "animation-play-state": "running",//让歌曲图片旋转
        })
    } else {
        $(this).removeClass('fa-pause').addClass('fa-play');//切换控件
        $("audio").get(0).pause();//暂停音乐
        $(".cover").css({
            "animation-play-state": "paused",//让歌曲图片停止旋转
        })
            }
            renderMusicList(musiclist);//重新刷新歌曲数据
        });
            // 给上一首按钮绑定点击事件
$("#prevBtn").on("click", function () {
    if (currentIndex > 0) {
        currentIndex--;
        $(".time").text('00:00');//恢复初始化
    } else {
        currentIndex = musiclist.length - 1;
  }
$("#playBtn").removeClass('fa-pause').addClass('fa-play');
    $(".cover").css({
    "animation-play-state": "paused",
  });
  // 重新渲染歌曲信息
  render(musiclist[currentIndex]);
  // 让音乐播放
});
        // 给下一首按钮绑定点击事件
$("#nextBtn").on("click", function () {
  if (currentIndex < musiclist.length - 1) {
    currentIndex++;
    $(".time").text('00:00');//恢复初始化
  } else {
    currentIndex = 0;
  }
  // 重新渲染歌曲信息
  render(musiclist[currentIndex]);
  // 让音乐播放
    $("#playBtn").removeClass('fa-pause').addClass('fa-play');
    $(".cover").css({
    "animation-play-state": "paused",
  });
});
$("audio").on("timeupdate", function () {
  // 获取音乐当前到的时间，单位：秒
  var currentTime = $("audio").get(0).currentTime || 0;
  // 获取音乐的总时长，单位：秒
  var duration = $("audio").get(0).duration || 0;
  // 设置当前播放时间
  $(".current-time").text(formatTime(currentTime));
  // 设置进度条
  var value = (currentTime / duration) * 100;
  $(".music_progress_line").css({
    width: value + "%",
  });
});
$("audio").on("ended", function () {
  $("#playBtn").removeClass("fa-pause").addClass("fa-play");
  // 让封面旋转暂停
  $(".cover").css({
    "animation-play-state": "paused",
  });

  $("#nextBtn").trigger("click")
    if (currentIndex < musiclist.length - 1) {
    currentIndex++;
  } else {
    currentIndex = 0;
  }
    render(musiclist[currentIndex]);
  // 让音乐播放
    $("#playBtn").trigger("click")
});
$("#zongBtn").on("click",function () {   //列表样式和播放器及控件样式更改
   if ($(this).hasClass('fa-list')){
       $(this).removeClass('fa-list').addClass('fa-indent')
       $(".Subframe").css({"border-radius": "15px 0px 0px 15px"})
       $(".player_music").css({"display":"block"})
   }else {
       ($(this).removeClass('fa-indent').addClass('fa-list'))
       $(".Subframe").css({"border-radius": "15px"})
       $(".player_music").css({"display":"none"})
   }
})
// 通过事件委托给音乐列表的播放按钮绑定点击事件
$(".music-list").on("click", ".play-circle", function () {
  if ($(this).hasClass("fa-play-circle")) {
    var index = $(this).attr("data-index");
    currentIndex = index;
    render(musiclist[currentIndex]);
    $("#playBtn").trigger("click");
  } else {
    $("#playBtn").trigger("click");
  }
});
// 格式化时间
function formatTime(time) {
  // 329 -> 05:29
  var min = parseInt(time / 60);
  var sec = parseInt(time % 60);
  min = min < 10 ? "0" + min : min;
  sec = sec < 10 ? "0" + sec : sec;

  return `${min}:${sec}`;
}
function render(data) { //获取文件里的信息并改变html文本里面的内容
            $(".name").text(data.name);
            $(".singer").text(`${data.singer} - ${data.album}`);
            $(".cover").attr("src", data.cover);
            $("audio").attr("src", data.audio_url);
            $(".bg").css({
                background: `url("${data.cover}") no-repeat center center`,
            });
        }
function renderMusicList(list) { //音乐列表获取
    $(".music-list").empty();
    $.each(list, function (index, item) {
        var $li = $(`
      <li  class="${index == currentIndex ? "playing" : ""}">
        <span>${index + 1}. ${item.name} - ${item.singer}</span>
        <span data-index="${index}" onclick="bgs('2')" class="fa ${
            index == currentIndex && !$("audio").get(0).paused
                ? "fa-pause-circle"
                : "fa-play-circle"
        } play-circle"></span>
      </li>
    `);
        $(".music-list").append($li);// 根据歌曲数量进行更改
    });
}
function bgs() { //设置控件点击事件如果点击获取音频文件的总时长，避免溢出//获取音乐总时长并改变页面数据
            if(_audio.readyState > 0) {
            let minutes = parseInt(_audio.duration / 60, 10);
            let seconds = parseInt(_audio.duration % 60);
            if (seconds < 10) {
                seconds = "0" + seconds
                $(".time").text("0" + minutes + ":" + seconds);
            } else {
                $(".time").text("0" + minutes + ":" + seconds);//获取歌曲总时长
                console.log()
            }
        }
    }
$("#Btn").on("click",function (){
    ($("#zongBtn").removeClass('fa-indent').addClass('fa-list'))
    $(".Subframe").css({"border-radius": "15px"})
    $(".player_music").css({"display":"none"})
})